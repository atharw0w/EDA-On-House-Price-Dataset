# EDA-on-House-Price-Dataset

I have done EDA(Exploratory Data Analysis) on House Price Dataset to gain insights on the various factors affecting the SalesPrice using Data Visualization 
along with handling the missing values and removing the outliers using Standardization techniques.

Here i have uses pandas library and seaborn library for the EDA purpose. From the various scatterplots, Heatmap we got to know about the collinearity and remove the
redundant features or basically multicollinearity. To remove the outliers i have used standarization techniques provided by the sklearn library. Using the scatter plots
we were able to know the types of relationship any two features follow such as linear, exponential,etc. 

After analyzing the data we can see OverallQual , BuiltYear, LivingArea were the prime features which affect the SalesPrice of a house majorly.
